'use strict';

//Static variables used in doris-importer-ui project

var DORIS_API_URL = "http://localhost:8080/doris-importer-api/";
var DORIS_UI_URL = "http://localhost:8080/doris-importer-ui/";
var DORIS_BOARD_URL = "http://localhost:8080/dorisBoard/";