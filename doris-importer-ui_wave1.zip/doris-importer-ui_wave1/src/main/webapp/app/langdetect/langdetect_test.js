'use strict';

describe('myApp.qa module', function() {

  beforeEach(module('myApp.qa'));

  describe('qa controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view2Ctrl = $controller('View2Ctrl');
      expect(view2Ctrl).toBeDefined();
    }));

  });
});