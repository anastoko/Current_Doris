'use strict';

angular.module('myApp.langdetect', ['ngRoute', 'ngResource', 'angular-loading-bar'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/langdetect', {
            templateUrl: 'langdetect/langdetect.html',
            controller: 'LangDetectCtrl'
        });
    }])
    .factory('LanguageDetector', ['$resource', '$rootScope',function ($resource, $rootScope) {
        return $resource($rootScope.dorisApiUrl + 'api/language', {}, {
            detectLanguage: {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        });
    }])

    .controller('LangDetectCtrl', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , 'LanguageDetector'
        , function ($scope,
                    $rootScope,
                    $httpParamSerializerJQLike,
                    LanguageDetector) {

            $scope.init = function(){
                $scope.showSuccess = false;
                $scope.showError = false;
            }

            $scope.detect = function () {
            	
                LanguageDetector.detectLanguage($httpParamSerializerJQLike({
                    alias: $rootScope.alias,
                    method: $rootScope.method
                })).$promise.then(function () {
                    $scope.showSuccess = true;
                }).catch(function (response) {
                    $scope.errorMessage = response.data.message;
                    $scope.showError = true;
                });
            };
        }]);