/**
 * Created by perezom on 16/08/2016.
 */
'use strict';

angular.module('myApp.solr', ['ngRoute', 'ngResource', 'angular-loading-bar'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/solr', {
            templateUrl: 'solr/solr.html',
            controller: 'SolrCtrl'
        });
    }])
    .factory('SolrIndexer', ['$resource','$rootScope', function ($resource,$rootScope) {
        return $resource($rootScope.dorisApiUrl + 'api/solr', {}, {
            index: {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        });
    }])

    .controller('SolrCtrl', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , '$http'
        , 'SolrIndexer'
        , function ($scope,
                    $rootScope,
                    $httpParamSerializerJQLike,
                    $http,
                    SolrIndexer) {

            $scope.init = function(){
                $scope.showSuccess = false;
                $scope.showError = false;
            }
            
            // Function to show the pop up to confirm the restarting of Solr          
            $scope. goConfirmationRestartSolr= function () {
            	$('#modalConfirmationRestartSolr').modal('show');
        	}
            
            // Function to hide the pop up to confirm the restarting of Solr  
            $scope.goHideConfirmationRestartSolr= function () {
               	$('#modalConfirmationRestartSolr').modal('hide');
            }
            
            // Function to restart Solr
            $scope.goRestartSolr= function () {	
            	console.log("ha entrado en la funcion")
            	$("#wrapper").addClass("loading");
            	$http.get($rootScope.dorisApiUrl + "api/solr/restartSolr",{}).then(function(response){
            			$("#wrapper").removeClass("loading");
            			console.log("ha habido respuesta")
            			var receivedData = JSON.parse(JSON.stringify(eval(response.data)));
            			if(receivedData.error == ""){
            				$scope.showError= false;
            				$scope.showSuccess= true;
            				$scope.successMessage =receivedData.data;
            				$('#modalConfirmationRestartSolr').modal('hide');
            				$('#startSolrIndex').show();
            			}else{
            				$scope.showError= true;
            				$scope.showSuccess= false;
            				$scope.errorMessage = receivedData.error; 
            			}
            		})
            	}

            
          

            $scope.index = function () {
                SolrIndexer.index($httpParamSerializerJQLike({
                    alias: $rootScope.alias,
                    method: $rootScope.method
                })).$promise.then(function () {
                    $scope.showSuccess = true;
                    $scope.successMessage = "SOLR Index for consultation has finished successfully";
                }).catch(function (response) {
                    $scope.errorMessage = response.data.message;
                    $scope.showError = true;
                });
            };
        }
        ]);