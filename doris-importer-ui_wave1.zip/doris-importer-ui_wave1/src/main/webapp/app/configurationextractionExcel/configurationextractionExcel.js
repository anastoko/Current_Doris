'use strict';

angular.module('myApp.configurationextractionExcel', ['ngRoute', 'ngResource', 'angular-loading-bar','ngSanitize','ui.bootstrap'])

    .config(['$routeProvider', function ($routeProvider) {
    	$('#languageDetectDiv').hide();
        $routeProvider.when('/configurationextractionExcel', {
            templateUrl: 'configurationextractionExcel/configurationextractionExcel.html',
            controller: 'configurationextractionExcelController'
        });
    }])
    .factory('configurationextractionExcel', ['$resource','$rootScope', function ($resource,$rootScope) {
        return $resource($rootScope.dorisApiUrl + 'api/configurationextractionExcel', {}, {
        	extractData: {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        });
    }])

    .controller('configurationextractionExcelController', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , '$http'
        , 'configurationextractionExcel'
        , function ($scope,
                    $rootScope,
                    $httpParamSerializerJQLike,
                    $http,
                    configurationextractionExcel) {   
        	
        	//////////////////////////////////////
			// Function to initialize the screen//
			//////////////////////////////////////
        	$scope.initializeScreen = function() {
        		$scope.showSuccess = false;
        		
        		$("#generalInformationWrapDiv").hide();
        		$("#userTypesWrapDiv").hide();
        		$("#informationCitizensWrapDiv").hide();
        		$("#informationOrganizationsWrapDiv").hide();

        		$("#titleSendToLoadDiv").hide();
        		$("#previousButtonExcelyDiv").hide();
        		$("#nextButtonExcelDiv").hide();
        		$("#submmitButtonDiv").hide();
        		
        		$("#pendingConsultationsWrapDiv").show();
        		$("#titleConsultationsList").hide();
        		
        		$scope.showInfo = false;
        		$scope.showSuccess = false;
        		$scope.showError = false;
	
        		
        	};
        	
        	$scope.initializeScreen();
        		
        	///////////////////////
			// Data to questions //
			///////////////////////
        	
    		$scope.questionsIdentified = [
  			  {listName: "Questions identified in the consultation", items: [], dragging: false}];
  			
  			// Generate the initial model
  			

  			  for (var i = 1; i <= 9; ++i) {
  				  $scope.questionsIdentified[0].items.push({label: "Question" +i});
  			  }
        	
  			  
  			  
  			////////////////////////////
  			// Data to Matching types //
  			////////////////////////////
  			  
  			$scope.dataForMatchingUserType = [
				  {listName: "User Types identified in the consultation", items: [], dragging: false},
				  {listName: "User type: CITIZEN", items: [], dragging: false},
				  {listName: "User type: ORGANIZATION", items: [], dragging: false},
				  {listName: "User type: ADMINISTRATION", items: [], dragging: false},
				  {listName: "User type: OTHER", items: [], dragging: false}
				  
				];

			//////////////////////////////////
			// Data to information citizens //
			//////////////////////////////////
					

			$scope.informationCitizensData = [
			  {listName: "Questions of the consultation", items: [], dragging: false},
			  {listName: "Questions about citizens", items: [], dragging: false}
			  
			];
			
  			///////////////////////////////////////////
  			// Data to Matching information citizens //
  			///////////////////////////////////////////
  			  
  			$scope.dataForMatchingInformationCitizens = [
  				  {listName: "Questions about citizens selected", items: [], dragging: false},
				  {listName: "Country of the citizen", items: [], dragging: false},
				  {listName: "Name of the citizen", items: [], dragging: false},
				  {listName: "Surname of the citizen", items: [], dragging: false},
				  {listName: "Email of the citizen", items: [], dragging: false}  
				];
			
			
			///////////////////////////////////////
			// Data to information organizations //
			///////////////////////////////////////
					

			$scope.informationOrganizationsData = [
			  {listName: "Questions of the consultation", items: [], dragging: false},
			  {listName: "Questions about organizations and administrations", items: [], dragging: false}
			  
			];
			
  			////////////////////////////////////////////////
  			// Data to Matching information organizations //
  			////////////////////////////////////////////////
  			  
  			$scope.dataForMatchingInformationOrganizations = [
  				  {listName: "Questions about organizations selected", items: [], dragging: false},
				  {listName: "Country of the organization", items: [], dragging: false},
				  {listName: "Name of the respondent", items: [], dragging: false},
				  {listName: "Email of the respondent", items: [], dragging: false},
				  {listName: "Name of the organization", items: [], dragging: false}  
				];
			
			////////////////////////////////
			// Data to information caseId //
			////////////////////////////////
					

			$scope.informationCaseIdData = [
			  {listName: "Questions of the consultation", items: [], dragging: false}
			  
			];
			
			///////////////////////////////////////////////////
			// Functions to control the drop and drags lists //
			///////////////////////////////////////////////////

			/**
			 * dnd-dragging determines what data gets serialized and send to the receiver
			 * of the drop. While we usually just send a single object, we send the array
			 * of all selected items here.
			 */
			$scope.getSelectedItemsIncluding = function(list, item) {
			  item.selected = true;
			  return list.items.filter(function(item) { return item.selected; });
			};

			/**
			 * We set the list into dragging state, meaning the items that are being
			 * dragged are hidden. We also use the HTML5 API directly to set a custom
			 * image, since otherwise only the one item that the user actually dragged
			 * would be shown as drag image.
			 */
			$scope.onDragstart = function(list, event) {
			   list.dragging = true;
			   if (event.dataTransfer.setDragImage) {
				 var img = new Image();
				 img.src = 'framework/vendor/ic_content_copy_black_24dp_2x.png';
				 event.dataTransfer.setDragImage(img, 0, 0);
			   }
			};

			/**
			 * In the dnd-drop callback, we now have to handle the data array that we
			 * sent above. We handle the insertion into the list ourselves. By returning
			 * true, the dnd-list directive won't do the insertion itself.
			 */
			$scope.onDrop = function(list, items, index) {
			  angular.forEach(items, function(item) { item.selected = false; });
			  list.items = list.items.slice(0, index)
						  .concat(items)
						  .concat(list.items.slice(index));
			  return true;
			}

			/**
			 * Last but not least, we have to remove the previously dragged items in the
			 * dnd-moved callback.
			 */
			$scope.onMoved = function(list) {
			  list.items = list.items.filter(function(item) { return !item.selected; });
			};

			// Model to JSON for demo purpose
			$scope.$watch('models', function(model) {
				$scope.modelAsJson = angular.toJson(model, true);
			}, true);
			
			
			////////////////////////////////////////////////////
			// Functions to control the next-previous buttons //
			////////////////////////////////////////////////////
			
			$scope.dataSet = [
				{name:"pendingConsultationsWrapDiv",index:0},
				{name:"generalInformationWrapDiv",index:1},
				{name:"userTypesWrapDiv",index:2},
				{name:"informationCitizensWrapDiv",index:3},
				{name:"informationOrganizationsWrapDiv",index:4},
				{name:"caseIdWrapDiv",index:5},
				{name:"titleSendToLoadDiv",index:6}
			],
			
			
			$scope.current = $scope.dataSet[0],
			
			// Function to next button
			$scope.next = function(){
				var i = $scope.getIndex($scope.current.index, 1);
				var showMessages = false;
				if($scope.current.index==1){
					showMessages = $scope.checkGeneralInformation();
				}
				if($scope.current.index==2){
					showMessages = $scope.checkUserType();
				}
				if($scope.current.index==3){
					showMessages = $scope.checkInformationCitizen();
				}
				if($scope.current.index==4){
					showMessages = $scope.checkInformationOrganization();
				}
				if($scope.current.index==5){
					showMessages = $scope.checkCaseId();
				}
				if(!showMessages){
					if($scope.qidUserTypeQuestion == "noQuestion"&& i==3){
						$scope.goChosenPage(5)
						$scope.getButtonsDisabled(5);
					}else{
						$scope.goChosenPage(i);
						$scope.getButtonsDisabled(i);
					}
				}
			},
			
			// Function to previous button
			$scope.previous = function(){
				var i = $scope.getIndex($scope.current.index, -1);
				if($scope.qidUserTypeQuestion == "noQuestion" && i==4){
					$scope.goChosenPage(2);
					$scope.getButtonsDisabled(2);
				}else{
					$scope.goChosenPage(i);
					$scope.getButtonsDisabled(i);
				}			
			},
			
			// Function to go to the chosen page
			$scope.goChosenPage = function(i){
				$scope.current = $scope.dataSet[i];
				var nameDiv = "";
				for ( var count=0; count < $scope.dataSet.length; count++){
					var nameDiv = "#" + $scope.dataSet[count].name
					if(count == i){
						// If user is in the last page, "Send information" button has to be instead of "Next" button
						if (count == $scope.dataSet.length-1){
							$("#nextButtonExcelDiv").hide();
							$("#submmitButtonDiv").show();
						} else{
							$("#nextButtonExcelDiv").show();
							$("#submmitButtonDiv").hide();
						}
						$(nameDiv).show();
					}else{
						$(nameDiv).hide();
					}
				}
			}
			
			// Function to disable the buttons next-previous
			$scope.getButtonsDisabled = function(i){
				if(i==0){
					$scope.disabledPrevious = true;
					$scope.disabledNext = false;
				}
				else if(i == ($scope.dataSet.length)-1){
					$scope.disabledPrevious = false;
					$scope.disabledNext = true;
				}
				else{
					$scope.disabledPrevious = false;
					$scope.disabledNext = false;
				}

			}
			
			// Function to get the screen in where the user wants to go
			$scope.getIndex = function(currentIndex, shift){
				var len = $scope.dataSet.length;
				return (((currentIndex + shift) + len) % len)
			}
			
			$scope.dataOwners = []
			$scope.dataUnits = []
			
			//////////////////////////////
			// Functions to add buttons //
			//////////////////////////////
			
			$scope.addOwnerButton = function(){
				var newOwner = $("#ownerName").val();
				if (newOwner != ""){
					try{
						$scope.dataOwners.push(newOwner);
						$("#ownerName").val("");
						$("#buttonsOwnersWrap").show();
					}catch(err){
						$scope.showError= true;
						$scope.messageError = "The typed owner has already added";
					}
				}
			};
			
			$scope.removeOwnerButton = function(ownerToDelete){
				for(var i=0; i<$scope.dataOwners.length ; i++){
					if(ownerToDelete ===$scope.dataOwners[i]){
						$scope.dataOwners.splice(i,1);
						if ($scope.dataOwners.length ==0){
							$("#buttonsOwnersWrap").hide();
						}
					}
				}			
			}
			
			$scope.addUnitButton = function(){
				var newUnit = $("#unitName").val();
				if (newUnit != ""){
					try{
						$scope.dataUnits.push(newUnit);
						$("#unitName").val("");
						$("#buttonsUnitsWrap").show();
					}catch(err){
						$scope.showError= true;
						$scope.messageError = "The typed unit has already added";
						
					}
				}
			};
			
			$scope.removeUnitButton = function(unitToDelete){
				for(var i=0; i<$scope.dataUnits.length ; i++){
					if(unitToDelete ===$scope.dataUnits[i]){
						$scope.dataUnits.splice(i,1);
						if ($scope.dataUnits.length ==0){
							$("#buttonsUnitsWrap").hide();
						}
					}
				}			
			};
			
			///////////////////////////////////////////////////////////////////////////////////////
			// Function to get the Excel consultations pending to extract data in DORIS system//
			///////////////////////////////////////////////////////////////////////////////////////
			
			$scope.getConsultationsPendingLoad = function(){
				
				$("#wrapper").addClass("loading");
				
				$http.get($rootScope.dorisApiUrl + "api/configurationextractionExcel/listSurveys",{})
            	.then(function(response){
					$("#wrapper").removeClass("loading");		
            		var receivedData = JSON.parse(JSON.stringify(eval(response.data)))
					if(receivedData.error == ""){
						$scope.showError= false;
						$scope.pendingConsultations = receivedData.data
						$("#titleConsultationsList").show();
						$("#dropDownPendingListDiv").show();
						$scope.titleDropDownPendingList = "Choose a consultation";
					}else{
						$scope.showError= true;
					}
            	})
				
			};
			
			///////////////////////////////////////////////////////////////
			// Function to get the identified question in a consultation //
			///////////////////////////////////////////////////////////////
			
			$scope.getQuestionsFromConsultation = function(aliasConsultation){
				$scope.showInfo= false;
				$scope.showError= false;
				$rootScope.alias = aliasConsultation;
				$scope.titleDropDownPendingList = aliasConsultation;
				
				$("#wrapper").addClass("loading");
				
				$http.get($rootScope.dorisApiUrl + "api/configurationextractionExcel/listQuestionsExcelConsultation",{
					params : {
            			"aliasConsultation" : aliasConsultation
            		}
					
				}).then(function(response){
					$("#wrapper").removeClass("loading");
					$rootScope.method = "EXCEL"
            		var receivedData = JSON.parse(JSON.stringify(eval(response.data)))
					if(receivedData.error == ""){
						$scope.questionsIdentified = receivedData.data
						$scope.questionsIdentified.unshift({qid:"noQuestion",text:"There are no questions related to this information",textToDisplay:"There are no questions related to this information" });
						
						// Show the PREV/NEXT buttons
						$("#previousButtonExcelDiv").show();
						$("#nextButtonExcelDiv").show();
						$scope.disabledPrevious = true;
						
						// Generate the initial information citizens
						for (var i = 0; i < ($scope.questionsIdentified).length; ++i) {

							$scope.informationCitizensData[0].items.push({label: $scope.questionsIdentified[i].text, qid :  $scope.questionsIdentified[i].qid, textToDisplay :  $scope.questionsIdentified[i].textToDisplay});
						}
						
						// Generate the initial information organizations
						for (var i = 0; i < ($scope.questionsIdentified).length; ++i) {

							$scope.informationOrganizationsData[0].items.push({label: $scope.questionsIdentified[i].text,qid:$scope.questionsIdentified[i].qid, textToDisplay :  $scope.questionsIdentified[i].textToDisplay});
						}
						  
						// Generate the initial information caseId
						for (var i = 0; i < ($scope.questionsIdentified).length; ++i) {
							$scope.informationCaseIdData[0].items.push({label: $scope.questionsIdentified[i].text,qid:$scope.questionsIdentified[i].qid,textToDisplay :  $scope.questionsIdentified[i].textToDisplay});
						}
						
						$scope.showError= false;
					}else{
						$scope.showError= true;
					}
            	})
				
			};

			
			//////////////////////////////////////////////////////////////////////////////////////
			// Function to get the answers identified for a specific question of a consultation //
			//////////////////////////////////////////////////////////////////////////////////////
			
			$scope.qidUserTypeQuestion = "";
			$scope.getAnswersFromQuestion = function(qid,textQuestion){
				
				//Set the qid and text of the selected question
				$scope.qidUserTypeQuestion = qid;
				$scope.textUserTypeQuestion = textQuestion;
				
				//Hide the title of matching user types
				$("#subTitleUserTypesDiv1").hide();
				
				
				//Remove the user types identified in the consultation and the standard user types
				for(var i=0;i < ($scope.dataForMatchingUserType).length; i++){
					$scope.dataForMatchingUserType[i].items = [];
				}
				
				//Check if NO QUESTIONS have been selected
				
				if(qid == "noQuestion"){
					$("#subTitleUserTypesDiv3").show();
					$("#userTypesStandard").hide();
					$("#userTypesIdentifiedDiv").hide();
					$("#subTitleUserTypesDiv2").hide();
					$("#questionsIdentifiedDiv").hide();
				}else{
					$("#subTitleUserTypesDiv3").hide();	
					
					$("#wrapper").addClass("loading");
					
					$http.get($rootScope.dorisApiUrl + "api/configurationextractionExcel/listAnswersFromQuestion",{
						params : {
	            			"aliasConsultation" : $rootScope.alias,
	            			"qid": qid
	            		}
						
					}).then(function(response){
						$("#wrapper").removeClass("loading");		
	            		var receivedData = JSON.parse(JSON.stringify(eval(response.data)))
	            		if(receivedData.error == ""){
	            			$("#questionsIdentifiedDiv").hide();
	            			$("#subTitleUserTypesDiv2").show();
	            			$("#userTypesIdentifiedDiv").show();
	            			$("#userTypesStandard").show();
	            			
	            			//Add the user types identified in the consultation
	            			$scope.anwsersIdentifiedFromQuestion = receivedData.data
	            			for (var i = 0; i < ($scope.anwsersIdentifiedFromQuestion).length; ++i) {
	            				$scope.dataForMatchingUserType[0].items.push({label: $scope.anwsersIdentifiedFromQuestion[i].text,textToDisplay: $scope.anwsersIdentifiedFromQuestion[i].textToDisplay});
	            			}
							
							$scope.showError= false;
						}else{
							$scope.showError= true;
						}
	            	})
				}
				
				
				
			
			};
			
			////////////////////////////////////////
			// Function to set the country chosen //
			////////////////////////////////////////
			
			$scope.setCountryQuesion = function(qid){
			};
			
			////////////////////////////////////////
			// Function to set the caseId chosen //
			////////////////////////////////////////
			
			$scope.qidCaseId = "";
			$scope.setCaseId = function(qid){
				$scope.qidCaseId = qid;
			};

			//////////////////////////////////////////////
			// Function to send all information and     //
			//  load the consultation into DORIS system //
			//////////////////////////////////////////////
			
			$scope.sendToLoad = function(){
				
				$("#wrapper").addClass("loading");
				
				
				//Create the userTypeMatching to send				
				var userTypeMatchingToSend = {};
				for(var i = 0; i < ($scope.dataForMatchingUserType).length; ++i){
					var values = [];
					
					for(var j = 0; j < ($scope.dataForMatchingUserType[i].items).length; j++){
						values.push($scope.dataForMatchingUserType[i].items[j].label);
					}
					
					if(i==1){
						userTypeMatchingToSend["CITIZEN"] = values;
					}else if(i==2){
						userTypeMatchingToSend["ORGANIZATION"] = values;
					}else if(i==3){
						userTypeMatchingToSend["ADMINISTRATION"] = values;
					}else if(i==4){
						userTypeMatchingToSend["OTHER"] = values;
					}
				}
				
				//Create the citizen list to send				
				var citizenInfoListToSend = [];
				for(var i = 0; i < ($scope.informationCitizensData[1].items).length; ++i){
					citizenInfoListToSend.push($scope.informationCitizensData[1].items[i].qid);
				}
				
				//Create the matching information citizen to send
				var matchingInformationCitizenToSend = {};
				matchingInformationCitizenToSend["countries"] = "";
				matchingInformationCitizenToSend["name"] = "";
				matchingInformationCitizenToSend["surname"] = "";
				matchingInformationCitizenToSend["email"] = "";
				
				if (($scope.dataForMatchingInformationCitizens[1].items).length > 0){
					matchingInformationCitizenToSend["countries"] = $scope.dataForMatchingInformationCitizens[1].items[0].qid
				}
				if (($scope.dataForMatchingInformationCitizens[2].items).length > 0){
					matchingInformationCitizenToSend["name"] = $scope.dataForMatchingInformationCitizens[2].items[0].qid
				}
				if (($scope.dataForMatchingInformationCitizens[3].items).length > 0){
					matchingInformationCitizenToSend["surname"] = $scope.dataForMatchingInformationCitizens[3].items[0].qid
				}
				if (($scope.dataForMatchingInformationCitizens[4].items).length > 0){
					matchingInformationCitizenToSend["email"] = $scope.dataForMatchingInformationCitizens[4].items[0].qid
				}
				
				//Create the organization list to send				
				var organizationInfolistToSend = [];
				for(var i = 0; i < ($scope.informationOrganizationsData[1].items).length; ++i){
					organizationInfolistToSend.push($scope.informationOrganizationsData[1].items[i].qid);
				}
				
				//Create the matching information organization to send
				var matchingInformationOrganizationsToSend = {};
				matchingInformationOrganizationsToSend["countries"] = "";
				matchingInformationOrganizationsToSend["name"] = "";
				matchingInformationOrganizationsToSend["email"] = "";
				matchingInformationOrganizationsToSend["company_name"] = "";
				
				
				
				if (($scope.dataForMatchingInformationOrganizations[1].items).length > 0){
					matchingInformationOrganizationsToSend["countries"] = $scope.dataForMatchingInformationOrganizations[1].items[0].qid
				}
				if (($scope.dataForMatchingInformationOrganizations[2].items).length > 0){
					matchingInformationOrganizationsToSend["name"] = $scope.dataForMatchingInformationOrganizations[2].items[0].qid
				}
				if (($scope.dataForMatchingInformationOrganizations[3].items).length > 0){
					matchingInformationOrganizationsToSend["email"] = $scope.dataForMatchingInformationOrganizations[3].items[0].qid
				}
				if (($scope.dataForMatchingInformationOrganizations[4].items).length > 0){
					matchingInformationOrganizationsToSend["company_name"] = $scope.dataForMatchingInformationOrganizations[4].items[0].qid
				}
							
				
				var allDataToSend ={
            			"aliasConsultation" : $rootScope.alias,
            			"showDates": $scope.showDateButton,
            			"owners": $scope.dataOwners,
            			"units": $scope.dataUnits,
            			"active": $scope.activeButton,
            			"qidUserTypeQuestion": $scope.qidUserTypeQuestion,
            			"userTypeMatching": JSON.stringify(userTypeMatchingToSend),
            			"citizenInfoList": citizenInfoListToSend,
            			"organizationInfolist": organizationInfolistToSend,
            			"qidCaseId" : $scope.qidCaseId,
            			"informationCitizenMatching":JSON.stringify(matchingInformationCitizenToSend),
            			"informationOrganizationsMatching":	JSON.stringify(matchingInformationOrganizationsToSend)
				};
				
				console.log(allDataToSend);
				
				$http.post($rootScope.dorisApiUrl + "api/configurationextractionExcel/loadConsultationExcel",allDataToSend
						
					).then(function(response){
					$("#wrapper").removeClass("loading");
					
					var receivedData = JSON.parse(JSON.stringify(eval(response.data)));
					if(receivedData.error == ""){
						$scope.cleanAllElements();
						$scope.successMessage = "The consultation has been loaded in the system!";
						$scope.showSuccess= true;
						$scope.showError= false;
					}else{
						$scope.showSuccess= false;
						$scope.showError= true;
					}
				})
			};
			
			////////////////////////////////////
			// Function to clean all elements //
			////////////////////////////////////
			$scope.cleanAllElements = function(){
				
				$scope.dataOwners = [];
				$scope.dataUnits = [];
				$scope.showDateButton = null;
				$scope.activeButton = null;
				$scope.questionsIdentified[0].items = [];
				 for (var i = 0; i < $scope.dataForMatchingUserType.length; ++i) {
					 $scope.questionsIdentified[i].items = [];
				 }
				 for (var i = 0; i < $scope.informationCitizensData.length; ++i) {
					 $scope.informationCitizensData[i].items = [];
				 }
				 for (var i = 0; i < $scope.informationCitizensData.length; ++i) {
					 $scope.informationOrganizationsData[i].items = [];
				 }
				 $("#previousButtonExcelDiv").hide();
				 $("#nextButtonExcelDiv").hide();
				 
				 $scope.showInfo= false;
				 $scope.showError= false;
				 $scope.infoMessage = "";
				 $scope.errorMessage = "";
					
			};
			
			
			/////////////////////////////////////////////////////////////
			// Functions to check the parameters submmited by the user //
			/////////////////////////////////////////////////////////////
			
			//Check General Info	
			$scope.checkGeneralInformation = function(){
				$scope.showError= false;
				var showMessages = false;
				var infoMessage = "";
				var errorMessage = "";
				$scope.errorMessage = "";
				
				var tabInfoMessages = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				var tabErrorMessages = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				if($scope.dataOwners.length == 0){
					infoMessage += tabInfoMessages +"The field  'Who are the owners of the consultation?' is empty.<br/>";
				}
				if($scope.dataUnits.length == 0){
					infoMessage += tabInfoMessages +"The field  'What are the units of the consultation?' is empty.<br/>";
				}
				if($scope.showDateButton == null){
					errorMessage += tabErrorMessages +"The field  'Do you want to display the date?' is empty. It is required!<br/>";
				}
				if($scope.activeButton == null){
					errorMessage += tabErrorMessages +"The field  'Do you want to make the consultation active?' is empty. It is required!<br/>";
				}
				
				if(infoMessage != ""){
					$scope.showInfo= true;
					$scope.infoMessage = infoMessage.substring(tabInfoMessages.length-6, infoMessage.length); 	
				}else{
					$scope.showInfo= false;
					$scope.infoMessage = ""
				}
				if(errorMessage != ""){
					$scope.showError= true;
					$scope.errorMessage = errorMessage.substring(tabErrorMessages.length-12, errorMessage.length); 
					showMessages = true;
				}else{
					$scope.showError= false;
					$scope.errorMessage = "";
				}
				return showMessages;
			};
			
			//Check User type
			$scope.checkUserType = function(){
				var showMessages = false;
				var errorMessage = "";
				$scope.showError= false;
				$scope.errorMessage = "";
				if($scope.qidUserTypeQuestion == ""){
					errorMessage += "Any question related to User type has been identified. It is required!\n";
				}else{
					if($scope.dataForMatchingUserType[0].items.length != 0){
						errorMessage += "Some user type identified in the consultation has not been matched. It is required!\n";
					}
				}
				if(errorMessage != ""){
					$scope.showError= true;
					$scope.errorMessage = errorMessage; 
					showMessages = true;
				}
				return showMessages;
			};
			
			
			//Check Information Citizen
			$scope.checkInformationCitizen = function(){
				var showMessages = false;
				$scope.showError= false;
				var errorMessage = "";
				var tabErrorMessages = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				
				$scope.errorMessage = "";
				if($scope.informationCitizensData[1].items.length == 0){
					errorMessage += tabErrorMessages +"No question related to the personal information of citizens has been select. It is required!\n";
				}
				for(var i=0;i<$scope.informationCitizensData[1].items.length;i++){
					if($scope.informationCitizensData[1].items[i].qid == "noQuestion" && $scope.informationCitizensData[1].items.length>1){
						errorMessage += tabErrorMessages +"If you select 'There are no questions related to this information', you cannot select more questions.\n";
					}
				}
				
			

				if($scope.dataForMatchingInformationCitizens[1].items.length >1){
					errorMessage += tabErrorMessages +"Only one question can be chosen for 'Country of the citizen'\n";
				}
				if($scope.dataForMatchingInformationCitizens[2].items.length >1){
					errorMessage += tabErrorMessages +"Only one question can be chosen for 'Name of the citizen'\n";
				}
				if($scope.dataForMatchingInformationCitizens[3].items.length >1){
					errorMessage += tabErrorMessages +"Only one question can be chosen for 'Surname of the citizen'\n";
				}
				if($scope.dataForMatchingInformationCitizens[4].items.length >1){
					errorMessage += tabErrorMessages +"Only one question can be chosen for 'Email of the citizen'\n";
				}
				
				if(errorMessage != ""){
					$scope.showError= true;
					$scope.errorMessage = errorMessage.substring(tabErrorMessages.length-6, errorMessage.length);
					showMessages = true;
				}
				return showMessages;
			};
			
			//Check Information Organization
			$scope.checkInformationOrganization = function(){
				var showMessages = false;
				$scope.showError= false;
				var errorMessage = "";
				var tabErrorMessages = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				$scope.errorMessage = "";
	
				if($scope.informationOrganizationsData[1].items.length == 0){
					errorMessage += tabErrorMessages +"No question related to the personal information of organizations has been select. It is required!\n";
				}
				
				for(var i=0;i<$scope.informationOrganizationsData[1].items.length;i++){
					if($scope.informationOrganizationsData[1].items[i].qid == "noQuestion" && $scope.informationOrganizationsData[1].items.length>1){
						errorMessage += tabErrorMessages +"If you select 'There are no questions related to this information', you cannot select more questions.\n";
					}
				}
				

                if($scope.dataForMatchingInformationOrganizations[1].items.length >1){
                        errorMessage += tabErrorMessages +"Only one question can be chosen for " 
                                + $scope.informationOrganizationsData[1].listName + "\n";
                }
                if($scope.dataForMatchingInformationOrganizations[2].items.length >1){
                        errorMessage += tabErrorMessages +"Only one question can be chosen for " 
                                + $scope.informationOrganizationsData[2].listName + "\n";
                }
                if($scope.dataForMatchingInformationOrganizations[3].items.length >1){
                        errorMessage += tabErrorMessages +"Only one question can be chosen for " 
                                + $scope.informationOrganizationsData[3].listName + "\n";
                }
                if($scope.dataForMatchingInformationOrganizations[4].items.length >1){
                        errorMessage += tabErrorMessages +"Only one question can be chosen for " +
                                + $scope.informationOrganizationsData[4].listName + "\n";
                }

	
				if(errorMessage != ""){
					$scope.showError= true;
					$scope.errorMessage = errorMessage.substring(tabErrorMessages.length-6, errorMessage.length); 
					showMessages = true;
				}
				return showMessages;
			};
			
			//Check CaseId
			$scope.checkCaseId = function(){
				var showMessages = false;
				var errorMessage = "";
				$scope.showError= false;
				$scope.errorMessage = "";
				if($scope.qidCaseId ==""){
					errorMessage += "No question related to the information related to the unique identification of the respondents has been select. It is required!\n";
				}
				if(errorMessage != ""){
					$scope.showError= true;
					$scope.errorMessage = errorMessage; 
					showMessages = true;
				}
				return showMessages;
				
			};
			
			//////////////////
			// Close alerts //
			//////////////////
			
			$scope.closeAlert = function(idAlertDiv){
				if(idAlertDiv == "alertInfo"){
					$scope.showInfo= false;
				}else if(idAlertDiv == "alertSuccess"){
					$scope.showSuccess= false;
				}else if(idAlertDiv == "alertError"){
					$scope.showError= false;
				}
				
			}
			
			///////////////////////////////
			// Change question user type //
			///////////////////////////////
			
			$scope.changeQuestionUserType = function(){
				$("#subTitleUserTypesDiv1").show();
				$("#questionsIdentifiedDiv").show();
				$("#subTitleUserTypesDiv2").hide();
				$("#subTitleUserTypesDiv3").hide();
				$("#userTypesStandard").hide();
				$("#userTypesIdentifiedDiv").hide();
			}
			
			//////////////////////////////////////
			// Go matching information citizens //
			//////////////////////////////////////
			$scope.goMatchingInformationCitizens = function(){
				var showMessages = false;
				var tabErrorMessages = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
					
				//Remove the data for matching the information citizens
				for(var i=0;i < ($scope.dataForMatchingInformationCitizens).length; i++){
					$scope.dataForMatchingInformationCitizens[i].items = [];
				}
					
				if(($scope.informationCitizensData[1].items).length == 1){
					$scope.showError= false;
					$scope.errorMessage = "";
					$("#questionsIdentifiedCitizenDiv").hide();
					$("#matchingInformationButton").hide();
					$("#questionsInformationCitizensDiv").hide();
					$("#subTitleInformationCitizensDiv1").hide();
					if($scope.informationCitizensData[1].items[0].qid == "noQuestion"){
						$("#subTitleInformationCitizesDiv3").show();
						$("#questionsInformationCitizensDiv").hide();
						$("#subTitleInformationCitizensDiv1").hide();
						$scope.textInformationCitizensQuestion = $scope.informationCitizensData[1].items[0].textToDisplay;
						$scope.dataForMatchingInformationCitizens[0].items.push($scope.informationCitizensData[1].items[0])
					
					}else{
						$("#informationCitizensStandard").show();
						$("#questionsInformationCitizensDiv2").show();
						$("#subTitleInformationCitizensDiv2").show();
						$scope.dataForMatchingInformationCitizens[0].items.push($scope.informationCitizensData[1].items[0])
					}
					
				}else{
					for(var i=0;i < ($scope.informationCitizensData[1].items).length; i++){
						if($scope.informationCitizensData[1].items[i].qid == "noQuestion" && ($scope.informationCitizensData[1].items).length >1){
							showMessages=true;
						}
						$scope.dataForMatchingInformationCitizens[0].items.push($scope.informationCitizensData[1].items[i])
					}
					if(!showMessages){
						$("#questionsIdentifiedCitizenDiv").hide();
						$("#questionsInformationCitizensDiv").hide();
						$("#subTitleInformationCitizensDiv1").hide();
						$("#matchingInformationButton").hide();
						$("#informationCitizensStandard").show();
						$("#questionsInformationCitizensDiv2").show();
						$("#subTitleInformationCitizensDiv2").show();
						$scope.showError= false;
					}else{
						$scope.showError= true;
						$scope.errorMessage = "If you select 'There are no questions related to this information', you cannot select more questions.\n";
					}
						
					
				}	
			}
			
			//////////////////////////////////////////////////
			// Change the questions of information citizens //
			//////////////////////////////////////////////////
			$scope.changeQuestionsInformationCitizens = function(){
							
				//Remove the data for matching the information citizens
				for(var i=0;i < ($scope.dataForMatchingInformationCitizens).length; i++){
					$scope.dataForMatchingInformationCitizens[i].items = [];
				}
				
				$("#questionsIdentifiedCitizenDiv").show();
				$("#questionsInformationCitizensDiv").show();
				$("#subTitleInformationCitizensDiv1").show();
				$("#matchingInformationButton").show();
				$("#informationCitizensStandard").hide();
				$("#questionsInformationCitizensDiv2").hide();
				$("#subTitleInformationCitizensDiv2").hide();
				$("#subTitleInformationCitizesDiv3").hide();
			}
			
			///////////////////////////////////////////
			// Go matching information organizations //
			///////////////////////////////////////////
			$scope.goMatchingInformationOrganizations = function(){
				
				var showMessages = false;
				var tabErrorMessages = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
					
				//Remove the data for matching the information citizens
				for(var i=0;i < ($scope.dataForMatchingInformationOrganizations).length; i++){
					$scope.dataForMatchingInformationOrganizations[i].items = [];
				}
					
				if(($scope.informationOrganizationsData[1].items).length == 1){
					$scope.showError= false;
					$scope.errorMessage = "";
					$("#matchingInformationOrganizationsButton").hide();
					$("#questionsInformationOrganizationsDiv").hide();
					$("#subTitleInformationOrganizationsDiv1").hide();
					if($scope.informationOrganizationsData[1].items[0].qid == "noQuestion"){
						$("#subTitleInformationOrganizationsDiv3").show();
						$("#questionsIdentifiedOrganizationDiv").hide();
						$scope.textInformationOrganizationsQuestion = $scope.informationOrganizationsData[1].items[0].textToDisplay;
						$scope.dataForMatchingInformationOrganizations[0].items.push($scope.informationOrganizationsData[1].items[0])
					}else{		
						$("#informationOrganizationsStandard").show();
						$("#questionsIdentifiedOrganizationDiv").hide();
						$("#questionsInformationOrganizationsDiv2").show();
						$("#subTitleInformationOrganizationsDiv2").show();
						$scope.dataForMatchingInformationOrganizations[0].items.push($scope.informationOrganizationsData[1].items[0])
					}
				}else{
					for(var i=0;i < ($scope.informationOrganizationsData[1].items).length; i++){
						if($scope.informationOrganizationsData[1].items[i].qid == "noQuestion" && ($scope.informationOrganizationsData[1].items).length >1){
							showMessages=true;
						}
						$scope.dataForMatchingInformationOrganizations[0].items.push($scope.informationOrganizationsData[1].items[i])
					}
					
					if(!showMessages){
						$("#questionsIdentifiedOrganizationDiv").hide();
						$("#questionsInformationOrganizationsDiv").hide();
						$("#subTitleInformationOrganizationsDiv1").hide();
						$("#matchingInformationOrganizationsButton").hide();
						$("#informationOrganizationsStandard").show();
						$("#questionsInformationOrganizationsDiv2").show();
						$("#subTitleInformationOrganizationsDiv2").show();
						$scope.showError= false;
					}else{
						$scope.showError= true;
						$scope.errorMessage = "If you select 'There are no questions related to this information', you cannot select more questions.\n";
					}
						
					
				}	
			}
			
			//////////////////////////////////////////////////
			// Change the questions of information Organizations //
			//////////////////////////////////////////////////
			$scope.changeQuestionsInformationOrganizations = function(){
							
				//Remove the data for matching the information Organizations
				for(var i=0;i < ($scope.dataForMatchingInformationOrganizations).length; i++){
					$scope.dataForMatchingInformationOrganizations[i].items = [];
				}
				
				$("#questionsIdentifiedOrganizationDiv").show();
				$("#questionsInformationOrganizationsDiv").show();
				$("#subTitleInformationOrganizationsDiv1").show();
				$("#matchingInformationOrganizationsButton").show();
				$("#informationOrganizationsStandard").hide();
				$("#questionsInformationOrganizationsDiv2").hide();
				$("#subTitleInformationOrganizationsDiv2").hide();
				$("#subTitleInformationOrganizationsDiv3").hide();
			}
			
			
     

        }]);