/**
 * Created by perezom on 16/08/2016.
 */
angular.module('myApp.update', ['ngRoute', 'ngResource', 'angular-loading-bar'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/update', {
            templateUrl: 'update/update.html',
            controller: 'UpdateCtrl'
        });
    }])
    .factory('ConsultationGetter', ['$resource', function ($resource) {
        return $resource('http://34.253.79.72:8080/doris-importer-api/api/mongo/consultation/all', {}, {});
    }])

    .controller('UpdateCtrl', ['$scope'
        , '$rootScope'
        , 'ConsultationGetter'
        , function ($scope,
                    $rootScope,
                    ConsultationGetter) {
            $rootScope.filename = "No file required.";
            $scope.getNames = function () {
                ConsultationGetter.get()
                    .$promise.then(function (response) {
                    $scope.consultationNames = response.names;
                });
            }
        }
    ]);