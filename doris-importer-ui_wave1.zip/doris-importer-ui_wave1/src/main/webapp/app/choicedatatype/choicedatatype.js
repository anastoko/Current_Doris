'use strict';

angular.module('myApp.choicedatatype', ['ngRoute', 'ngResource', 'angular-loading-bar','ngSanitize','ui.bootstrap'])

    .config(['$routeProvider', function ($routeProvider) {
    	$('#languageDetectDiv').hide();
        $routeProvider.when('/choicedatatype', {
            templateUrl: 'choicedatatype/choicedatatype.html',
            controller: 'choicedatatypeController'
        });
    }])
    
    .factory('choicedatatype', ['$resource','$rootScope', function ($resource,$rootScope) {
        return $resource($rootScope.dorisApiUrl + 'api/choicedatatype', {}, {

        });
    }])

    .controller('choicedatatypeController', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , '$http'
        , 'choicedatatype'
        , function ($scope,
                    $rootScope,
                    $httpParamSerializerJQLike,
                    $http,
                    choicedatatype) {
        	
        	  $scope.goChoiceDataType = function () {
              	$('#choiceDataTypeDiv').show();
              	$('#fileUploadDiv').hide();
              	$('#configurationExtractionEusurveyDiv').hide();
        		$('#configurationExtractionBRPDiv').hide();
        		$('#configurationExtractionExcelDiv').hide();
        		$('#loadEusurveyDataDiv').hide();
              	$("#searchBoxTitle").val("");
              	$("#searchBoxReference").val("");
  				$scope.exactSearchButton = null;
  				$scope.showDateButton = null;
  				$scope.activeButton = null;
              	$('#chooseData').show();
          		$('#divUploadFile').hide();
          		$('#divTableUploadFile').hide();
             	$('#textExtractionBrp').hide();
          		$('#divSearchBoxInitiatives').hide();
          		$('#divTableInitiatives').hide();
          		$scope.showInfoPopUp= false;
          		$scope.showSuccess = false;
          		$scope.showError = false;
          		$scope.showInfo = false;
          		$('loadEusurveyData').hide();
  				$('#setAdminDiv').hide();
  				$('#languageDetectDiv').hide();
  				$('#translationDiv').hide();
  				$('#solrIndexDiv').hide();
  				$('#analyticsDiv').hide();
  				$('#similarityDiv').hide();
              };
        	
        	
        	 $scope.goChoiceDataType();
        	 
        	//Function to go to the upload of Excel file
        	
        	$scope.goExcelExtraction = function (){
        		$('#chooseData').hide();
        		$('#configurationExtractionEusurveyDiv').hide();
        		$('#configurationExtractionBRPDiv').hide();
        		$('loadEusurveyData').hide();

        		
        		$('#configurationExtractionExcelDiv').show();
        		$('#fileUploadDiv').show();
				$('#setAdminDiv').show();
				$('#languageDetectDiv').show();
				$('#translationDiv').show();
				$('#solrIndexDiv').show();
				$('#analyticsDiv').show();
				$('#similarityDiv').show();
				window.location.href = "#!/fileUpload";
				$rootScope.changeClass('fileUploadDiv');
				
        		
        	};
        	//Funcion para mostrar la configuracion de EUSurvey
        	
        	$scope.goEusurveyExtraction = function (){
        		$('#chooseData').hide();
        		$('#fileUploadDiv').hide();
        		$('#configurationExtractionBRPDiv').hide();
        		$('#configurationExtractionExcelDiv').hide();
        		
        		$('#divUploadFile').show();
        		$('#divTableUploadFile').show();
        		$('#divReturnButton').show();
        		
        		console.log("entra")
        		$('#loadEusurveyDataDiv').show();
        		$('#configurationExtractionEusurveyDiv').show(); 
				$('#setAdminDiv').show();
				$('#languageDetectDiv').show();
				$('#translationDiv').show();
				$('#solrIndexDiv').show();
				$('#analyticsDiv').show();
				$('#similarityDiv').show();
				window.location.href = "#!/loadEusurveyData";
				$rootScope.changeClass('loadEusurveyDataDiv');
        		
        	};
        	        	
        	//Funcion para mostrar la configuracion de BRP
        	$scope.goBrpExtraction = function (){
        		$('#chooseData').hide();
        		$('#configurationExtractionEusurveyDiv').hide();
        		$('#configurationExtractionExcelDiv').hide();
        		$('#textExtractionBrp').show();
        		$('#divSearchBoxInitiatives').show();

        		
        		$('#configurationExtractionBRPDiv').show();
        		$('loadEusurveyData').hide();
        		$('#fileUploadDiv').hide();
				$('#languageDetectDiv').show();
				$('#translationDiv').show();
				$('#setAdminDiv').show();
				$('#solrIndexDiv').show();
				$('#analyticsDiv').show();
				$('#similarityDiv').show();
				window.location.href = "#!/configurationextractionBRP";
				$rootScope.changeClass('configurationExtractionBRPDiv');
        	};	    	          
     

        }]);