'use strict';

describe('myApp.fileupload module', function() {

  beforeEach(module('myApp.fileupload'));

  describe('fileupload controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view1Ctrl = $controller('View1Ctrl');
      expect(view1Ctrl).toBeDefined();
    }));

  });
});