/**
 * Created by perezom on 11/08/2016.
 */

'use strict';

angular.module('myApp.fileUpload', ['ngRoute', 'ngFileUpload', 'angular-loading-bar'])

    .config(['$routeProvider', function ($routeProvider) {

        $routeProvider.when('/fileUpload', {
            templateUrl: 'fileupload/fileupload.html',
            controller: 'UploadController'
        });
    }])

    .controller('UploadController', ['$scope', '$rootScope', 'Upload', '$timeout', function ($scope, $rootScope, Upload, $timeout) {

    	$scope.uploadFiles = function (file, errFiles) {
    		$scope.f = file;
            $scope.errFile = errFiles && errFiles[0];
           
            if (file) {
            	$("#wrapper").addClass("loading");
                file.upload = Upload.upload({
                    url: $rootScope.dorisApiUrl + 'api/file',
                    data: {file: file}
                });

                file.upload.then(function (response) {
                	$("#wrapper").removeClass("loading");	
                    $timeout(function () {
                    	
                        file.result = response.data;
                        $rootScope.alias = response.data.alias;
                        $rootScope.filename = response.data.filename;
                        if(response.data.error == ""){
                        	$scope.showSuccess = true;
                        	$scope.successMessage = "The consultation has been loaded into DORIS sytem."
                        }
                    });
                }, function (response) {
                    if (response.status > 0)
                        $scope.errorMsg = response.status + ': ' + response.data;
                }, function (evt) {
                    file.progress = Math.min(100, parseInt(100.0 *
                        evt.loaded / evt.total));
                });
            }
        };
        
        
        /**
         * Funcion encargada de subir los position papers:
         * 1- Comprueba si el fichero tiene formato zip
         * 2- Comprueba si se ha subido ya una encuesta
         * 3- Sube el fichero y lo descomprime en la ruta correspondiente
         */
        $scope.uploadPositionPapers = function (file, errFiles) {

        	var fileType = (file.name).substring((file.name).indexOf("."), (file.name).length);
        	console.log(fileType);
        	if (file) {
	        	if(fileType != ".zip"){
	        		$scope.showError = true;
	        		$scope.errorMessage = "The file must be a ZIP file.";
	        		return false;
	        	} else if ( $rootScope.filename == null ){
	        		$scope.showError = true;
	        		$scope.errorMessage = "An EXCEL file must be selected before upload the ZIP file related to the attachment of the consultation";
	        	} else{
	        		file.upload = Upload.upload({
	                    url: $rootScope.dorisApiUrl + 'api/file/positionPapersfile',
	                    data: {file: file, alias: $rootScope.alias}
	                });
	        		file.upload.then(function (response) {
	                    $timeout(function () {
	                        file.result = response.data;
	                        console.log(response);
	                        console.log(response.data);
	                    });
	                }, function (response) {
	                    if (response.status > 0)
	                    	console.log("1");
                       
	                        $scope.errorMsg = response.status + ': ' + response.data;
	                }, function (evt) {
	                	console.log("1");
	                    file.progress = Math.min(100, parseInt(100.0 *
	                        evt.loaded / evt.total));
	                });
	        	}
        	}
        };        
    }]);