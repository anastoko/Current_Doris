/**
 * Created by perezom on 16/08/2016.
 */
'use strict';

angular.module('myApp.analytics', ['ngRoute', 'ngResource', 'angular-loading-bar'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/analytics', {
            templateUrl: 'analytics/analytics.html',
            controller: 'AnalyticsCtrl'
        });
    }])
    .factory('Enricher', ['$resource','$rootScope', function ($resource,$rootScope) {
        return $resource($rootScope.dorisApiUrl + 'api/analytics', {}, {
            startEnrichment: {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        });
    }])

    .factory('ProcessMonitor', ['$resource','$rootScope', function ($resource,$rootScope) {
        return $resource($rootScope.dorisApiUrl +'api/analytics/processes', {}, {});
    }])

    .controller('AnalyticsCtrl', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , 'Enricher'
        , 'ProcessMonitor'
        , function ($scope,
                    $rootScope,
                    $httpParamSerializerJQLike,
                    Enricher,
                    ProcessMonitor,
                    $websocket) {

            $scope.logLines = [];
            $scope.init = function () {
                $scope.showSuccess = false;
                $scope.showError = false;
            }

            $scope.enrich = function () {
                Enricher.startEnrichment($httpParamSerializerJQLike({
                    alias: $rootScope.alias
                })).$promise.then(function () {
                    $scope.showSuccess = true;
                }).catch(function (response) {
                    $scope.errorMessage = response.data.message;
                    $scope.showError = true;
                });
            };

            $scope.processMonitor = function () {
                ProcessMonitor.query().$promise.then(function (response) {
                    $scope.processes = response;
                });
            };

        }]);