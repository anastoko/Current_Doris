/**
 * Created by perezom on 18/08/2016.
 */

angular.module('myApp.srm', ['ngRoute', 'ngResource', 'angular-loading-bar', 'myApp.fileUpload'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/srm', {
            templateUrl: 'srm/srm.html',
            controller: 'SrmCtrl'
        });
    }])
    .factory('SRMImporter', ['$resource','$rootScope', function ($resource,$rootScope) {
        return $resource($rootScope.dorisApiUrl +'api/srm', {}, {
            sendToSRM: {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        });
    }])

    .controller('SrmCtrl', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , 'SRMImporter'
        , function ($scope,
                    $rootScope,
                    $httpParamSerializerJQLike,
                    SRMImporter) {

            $rootScope.alias = "";

            $scope.init = function(){
                $scope.showSuccess = false;
                $scope.showError = false;
            }

            $scope.sendToSRM = function () {
                SRMImporter.sendToSRM($httpParamSerializerJQLike({
                    alias: $rootScope.alias,
                    filename: $rootScope.filename
                })).$promise.then(function () {
                    $scope.showSuccess = true;
                }).catch(function (response) {
                    $scope.errorMessage = response.data.message;
                    $scope.showError = true;
                });
            };
        }]);