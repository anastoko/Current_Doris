'use strict';

angular.module('myApp.manual', ['ngRoute', 'ngResource', 'angular-loading-bar','ngSanitize','ui.bootstrap'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/manual', {
            templateUrl: 'manual/manual.html',
            controller: 'manualController'
        });
    }])
    .factory('manual', ['$resource','$rootScope', function ($resource,$rootScope) {
        return $resource($rootScope.dorisApiUrl + 'api/manual', {}, {
        	extractData: {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        });
    }])

    .controller('manualController', function ($scope,$rootScope,$httpParamSerializerJQLike,$http,$anchorScroll,$location,manual) {
			$scope.scrollTo = function(id) {
				$location.hash(id);
				$anchorScroll();
			}
        });