/**
 * Created by perezom on 16/08/2016.
 */
'use strict';

angular.module('myApp.similarity', ['ngRoute', 'ngResource', 'angular-loading-bar'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/similarity', {
            templateUrl: 'similarity/similarity.html',
            controller: 'SimilarityCtrl'
        });
    }])
    .factory('SimilarityEnricher', ['$resource', function ($resource) {
        return $resource('http://52.214.237.38:8080/doris-importer-api/api/similarity', {}, {
            startEnrichment: {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        });
    }])

    .factory('ProcessMonitorSimilarity', ['$resource', function ($resource) {
        return $resource('http://s-cnect-doris-d.cnect.cec.eu.int:8000/doris-importer-api/api/similarity/processes', {}, {});
    }])

    .controller('SimilarityCtrl', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , 'SimilarityEnricher'
        , 'ProcessMonitorSimilarity'
        , function ($scope,
                    $rootScope,
                    $httpParamSerializerJQLike,
                    SimilarityEnricher,
                    ProcessMonitorSimilarity) {

            $scope.logLines = [];
            $scope.thresholds = [' ', 0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1];
            $scope.distances = [' ', 'jaccard', 'alignment'];
            $scope.enricherData = {
                distance_type: 'jaccard',
                threshold: 0.7
            };

            $scope.init = function () {
                $scope.showSuccess = false;
                $scope.showError = false;
            }

            $scope.getScope = function(){
                return $scope;
            }

            $scope.setDistance = function (selectedDistance) {
                $scope.enricherData.distance_type = selectedDistance;
            }

            $scope.setThreshold = function (selectedThreshold) {
                $scope.enricherData.threshold = selectedThreshold;
            }

            $scope.enrich = function () {

                $scope.enricherData.consultation_name = $rootScope.alias;
                console.log($scope.enricherData);
                SimilarityEnricher.startEnrichment($httpParamSerializerJQLike($scope.enricherData)).$promise.then(function () {
                    $scope.showSuccess = true;
                }).catch(function (response) {
                    $scope.errorMessage = response.data.message;
                    $scope.showError = true;
                });
            };

            $scope.processMonitor = function () {
                ProcessMonitorSimilarity.query().$promise.then(function (response) {
                    $scope.processes = response;
                });
            };

        }]);