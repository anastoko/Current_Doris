'use strict';

angular.module('myApp.configurationextractionBRP', ['ngRoute', 'ngResource', 'angular-loading-bar','ngSanitize','ui.bootstrap'])

    .config(['$routeProvider', function ($routeProvider) {
    	$('#languageDetectDiv').hide();
        $routeProvider.when('/configurationextractionBRP', {
            templateUrl: 'configurationextractionBRP/configurationextractionBRP.html',
            controller: 'configurationextractionBRPController'
        });
    }])
    .factory('configurationextractionBRP', ['$resource', '$rootScope',function ($resource,$rootScope) {
        return $resource($rootScope.dorisApiUrl +'api/configurationextractionBRP', {}, {
       });
    }])

    .controller('configurationextractionBRPController', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , '$http'
        , 'configurationextractionBRP'
        , function ($scope,
                    $rootScope,
                    $httpParamSerializerJQLike,
                    $http,
                    configurationextractionBRP) {
        	
            
            //Funcion para cerrar el pop-up donde se confirma si desea continuar con la carga
            
            $scope.goHideConfirmationLoadData = function () {
            	$('#modalConfirmationLoadData').modal('hide');

            }
            
            //Funcion para cerrar el pop-up donde se confirma si se desea continuar y enseñar el de configuracion de parametros
            $scope.goParametersConfig = function (idInitiativeSelected) {
            	$scope.IdInitiativeSelected= idInitiativeSelected;
            	$('#modalConfirmationLoadData').modal('hide');
            	$('#modalParametersConfig').modal('show');
            }
        	
        	//Funcion para paginar la tabla
        	
        	$scope.paginacion = function (){ 
        		//Tabla paginacion
        		$scope.viewby = 10;
        		$scope.currentPage = 1;
        		$scope.itemsPerPage = $scope.viewby;
        		$scope.maxSize = 5; //Number of pager buttons to show
        		
        		$scope.setPage = function (pageNo) {
        			$scope.currentPage = pageNo;
        		};
        		$scope.pageChanged = function() {
        			console.log('Page changed to: ' + $scope.currentPage);
        		};
        		
        		$scope.setItemsPerPage = function(num) {
        			$scope.itemsPerPage = num;
        			$scope.currentPage = 1; //reset to first page
        		}
        	};
        	
        	//Funcion para comprobar si existe la iniciativa en mongoDB
        	$scope.checkIfInitiativeExists = function (idInitiative) {
        		
        		$("#displayName").val("");
				$("#shortName").val("");
				$scope.showDateButton = null;
				$scope.activeButton = null;
				
				
				$("#wrapper").addClass("loading");
				
							
        		$http.get($rootScope.dorisApiUrl + "api/configurationextractionBRP/checkInitiativeExist",{
            		params : {
            			"idInitiative" : idInitiative
            		}
            	})
            	.then(function(response){
					$("#wrapper").removeClass("loading");		
            		var receivedData = JSON.parse(JSON.stringify(eval(response.data)))
					if(receivedData.error == ""){
						$scope.showError= false;
						if (receivedData.loaded ==true){
							$('#modalConfirmationLoadData').modal('show');
							$scope.IdInitiativeSelected= idInitiative;
						}else{
							$('#modalParametersConfig').modal('show');
							$scope.IdInitiativeSelected= idInitiative;
						}
					}else{
						$scope.showError= true;
						$scope.errorMessage = receivedData.error; 
					}
            	})
        	};
        	
        	//Funcion para encontrar las iniciativas que contengan las palabras seleccionas en su titulo
            
        	$scope.getSearchedinitiatives = function () {
        		
        		$scope.showError= false;
        		$scope.showInfo= false;
        		$scope.showSuccess= false;

            	var titleInitiative = $("#searchBoxTitle").val();
            	var referenceInitiative = $("#searchBoxReference").val();
				var messageErrorCheckEmpty = ""
		
				if (titleInitiative == "" && referenceInitiative == ""){
					messageErrorCheckEmpty = "The fields 'Title of the initiative' and 'Reference of the initiative' are empty. You have to fill some of them!";
				}else{
					if (titleInitiative != "" && $scope.exactSearchButton == null){
						messageErrorCheckEmpty = "The field 'Do you want to make an exact search?' must be filled in";
					}
				}
               	
				
				if	(messageErrorCheckEmpty != ""){
					$('#divTableInitiatives').hide();
					$scope.showInfo= true;
                	$scope.errorValidationSearchBox = messageErrorCheckEmpty; 
				}else{
            		$scope.showInfo= false;
					console.log("sucess")

            		if ($scope.exactSearchButton == false){

            			titleInitiative = titleInitiative.replace(/ /g, '%');
            		}
            		if (titleInitiative == ""){
            			titleInitiative = null;
            		}
            		if (referenceInitiative == ""){
            			referenceInitiative = null;
            		}
					
					$("#wrapper").addClass("loading");
	            	$http.get($rootScope.dorisApiUrl +"api/configurationextractionBRP/search",{
	            		params : {
	            			"titleInitiative" : titleInitiative,
	            			"referenceInitiative":referenceInitiative
	            		}
	            	})
	            	.then(function(response){
						$("#wrapper").removeClass("loading"); 
	            		var receivedData = JSON.parse(JSON.stringify(eval(response.data)))
						if(receivedData.error == ""){
							$scope.showError= false;
							$scope.paginacion();
							$scope.totalItems = response.data.data.length;
							$scope.searchInitiativesList = response.data.data
							$('#divTableInitiatives').show();
						}else{
							$('#divTableInitiatives').hide();
							$scope.showError= true;
							$scope.errorMessage = receivedData.error; 
						}
	            	})
            	}
            };
            
            //Funcion para cargar y procesar la iniciativa seleccionada
            
            $scope.getFeedbackFromInitiative = function (idInitiative,authorName,units) {
				
				var errorMessage = "";
				
				if($("#displayName").val() == ""){
					errorMessage = errorMessage + "The field  'Display name of the initiative' is empty.  It is required!\n";
				}
				if($("#shortName").val() == ""){
					errorMessage = errorMessage + "The field  'Short name of the initiative' is empty.  It is required!\n";
				}
				if($scope.showDateButton == null){
					errorMessage = errorMessage + "The field  'Do you want to display the date?' is empty.  It is required!\n";
				}
				if( $scope.activeButton == null){
					errorMessage = errorMessage + "The field  'Do you want to make the consultation active?' is empty.  It is required!\n";
				}

             	
                
            	if (errorMessage != ""){
            		$scope.showInfoPopUp= true;
            		$scope.errorValidationPopUp = errorMessage;
            	}else{
            		$rootScope.alias=idInitiative + "_" + ($("#displayName").val()).replace(/ /g, '##');
            		$rootScope.method = "BRP"
            		$scope.showInfoPopUp= false;
            		$('#modalEdition').modal('hide');
					$("#wrapper").addClass("loading");
	            	$http.get($rootScope.dorisApiUrl+ "api/configurationextractionBRP/search/initiative",{
	            		params : {
	            			"idInitiative" : idInitiative,
	            			"displayName": $rootScope.alias,
	            			"shortName": $("#shortName").val(),
	            			"showDates": $scope.showDateButton,
	            			"active": $scope.activeButton
	            		}
	            	})
	            	.then(function(response){
						$("#wrapper").removeClass("loading");
						var receivedData = JSON.parse(JSON.stringify(eval(response.data)))
						$('#modalParametersConfig').modal('hide');
						$("#displayName").val("");
						$("#shortName").val("");
						$scope.showDateButton = null;
						$scope.activeButton = null;
						if(receivedData.error == ""){
							$('#divTableInitiatives').hide();
							$scope.showError= false;
							$scope.showSuccess= true;
							$scope.successMessage = "The initiative has been loaded in DORIS system!"
							$('#modalParametersConfig').modal('hide');
							
						}else{
							
							$scope.showError= true;
							$scope.errorMessage = receivedData.error; 
							
						}
	            			            		
	            	})
            	}
            };
     		
			//Funcion para comprobar que el campo titulo esta vacio y si es asi vaciamos la pregunta
            
            $scope.controlSearchBoxTitle = function () {
            	if ($("#searchBoxTitle").val() == ""){
					$scope.exactSearchButton = null;
				}
            };
            
  }]);