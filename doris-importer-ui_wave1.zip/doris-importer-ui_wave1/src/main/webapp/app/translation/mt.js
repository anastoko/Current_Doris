'use strict';

angular.module('myApp.machineTranslation', ['ngRoute', 'ngResource', 'angular-loading-bar'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/mt', {
            templateUrl: 'translation/mt.html',
            controller: 'TranslationCtrl'
        });
    }])
    .factory('MachineTranslator', ['$resource','$rootScope', function ($resource,$rootScope) {
        return $resource($rootScope.dorisApiUrl + 'api/translation', {}, {
            translate: {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        });
    }])

    .controller('TranslationCtrl', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , 'MachineTranslator'
        , function ($scope,
                    $rootScope,
                    $httpParamSerializerJQLike,
                    MachineTranslator) {

            $scope.init = function(){
                $scope.showSuccess = false;
                $scope.showError = false;
            }

            $scope.translate = function () {
                MachineTranslator.translate($httpParamSerializerJQLike({
                    alias: $rootScope.alias,
                    method: $rootScope.method
                })).$promise.then(function () {
                    $scope.showSuccess = true;
                }).catch(function (response) {
                    $scope.errorMessage = response.data.message;
                    $scope.showError = true;
                });
            };
        }]);