'use strict';

angular.module('myApp.log', ['ngRoute', 'ngResource', 'angular-loading-bar','ngSanitize','ui.bootstrap'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/log', {
            templateUrl: 'log/log.html',
            controller: 'logController'
        });
    }])
    .factory('log', ['$resource','$rootScope', function ($resource,$rootScope) {
        return $resource($rootScope.dorisApiUrl + 'api/log', {}, {
        	extractData: {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        });
    }])

    .controller('logController', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , '$http'
        , 'log'
        , function ($scope,$rootScope,$httpParamSerializerJQLike,$http,$anchorScroll,$location,log) {
			
            
            $scope.cleanLog = function () {
                $http.get($rootScope.dorisApiUrl +"api/log/cleanLog", {})
                
                //$scope.getLog();
                $scope.logs = ""

            }

            $scope.getLog = function () {
                /* HTTP request to obtain a list of logs as strings */
                $http.get($rootScope.dorisApiUrl +"api/log/getLog", {})
                .then(function(response){
                    var receivedData = JSON.parse(JSON.stringify(eval(response.data)))
                    if(receivedData.error == ""){
                        $scope.logs = response.data.data
                    }else{
                        $scope.errorMessage = receivedData.error;
                    }
                });
            }
            $scope.getLog()
        }]);