'use strict';


angular.module('myApp.loadEusurveyData', [	'ngRoute', 
					'ngResource', 
					'angular-loading-bar',
					'ngSanitize',
					'ui.bootstrap'])

	.config(['$routeProvider', function ($routeProvider) {
		$routeProvider.when('/loadEusurveyData', {
			    templateUrl: 'loadEusurveyData/loadEusurveyData.html',
			    controller: 'loadEusurveyDataController'
		});
	}])

	.factory('loadEusurveyData', ['$resource','$rootScope', function ($resource,$rootScope) {
		return $resource($rootScope.dorisApiUrl + 'api/eusurvey', {}, {
		        	extractData: {
		                method: 'POST',
		                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			}
		});
	}])

	.controller ( 'loadEusurveyDataController'  , [ 
		 	  '$scope' 
	        , '$rootScope'
	        , '$httpParamSerializerJQLike'
	        , '$http'
	        , 'loadEusurveyData'
		, function(	$scope,
                	$rootScope,
                    $httpParamSerializerJQLike,
                	$http,
                    extraction ){
	        	
	        	
        	/////////////////////////////////
			// Load data into DORIS system //
			/////////////////////////////////
						
			$scope.sendAlias = function() {
				
				var aliasToSearch = $("#aliasConsultation").val();
				
				if (aliasToSearch != ""){
					
					$("#wrapper").addClass("loading");
					
					$http.get($rootScope.dorisApiUrl +"api/eusurvey/insertAlias",{
	            		params : {
		            		"alias" : aliasToSearch,
	            		}
			        })
			        .then(function(response){
						$("#wrapper").removeClass("loading");
						var receivedData = JSON.parse(JSON.stringify(eval(response.data)))
	
						if(receivedData.error == ""){
							$scope.showError= false;
							$scope.showSuccess= true;
							$scope.successMessage = "The consultation has been downloaded in DORIS system!. It may take 15 minutes to be loaded. "
						}else{
							$scope.showError= true;
							$scope.errorMessage = receivedData.error; 
							
						}
			            			            		
			        })
	
				}
			};



		}]);
