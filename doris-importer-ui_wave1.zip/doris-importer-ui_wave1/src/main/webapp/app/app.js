'use strict';

// Declare app level module which depends on views, and components
angular.module('myApp', [
    'ngRoute',
    'myApp.choicedatatype',
    'myApp.configurationextractionBRP',
    'myApp.configurationextractionEusurvey',
    'myApp.configurationextractionExcel',
    'myApp.loadEusurveyData',
    'myApp.fileUpload',
    'myApp.qa',
    'myApp.langdetect',
    'myApp.machineTranslation',
    'myApp.solr',
    'myApp.update',
    'myApp.srm',
    'myApp.log',
    'myApp.analytics',
    'myApp.similarity',
    'myApp.manual',
    'myApp.version'
]).config(['$locationProvider', '$routeProvider', function ($locationProvider, $routeProvider) {
    $locationProvider.hashPrefix('!');

    $routeProvider.otherwise({redirectTo: '/choicedatatype'});
}])

    .controller('AppCtrl', ['$scope'
    	,'$rootScope'
        , function ($scope,
        			$rootScope) {
           
            $rootScope.dorisApiUrl = DORIS_API_URL;
            $rootScope.dorisUiUrl = DORIS_UI_URL;
            $rootScope.dorisBoardUrl = DORIS_BOARD_URL;
            
            $scope.action = false;
            $scope.setAction = function(action){
                $scope.action = action
            }
            
            $rootScope.changeClass = function(value){
                $scope.classVar= value; 
            }
           
        }]);