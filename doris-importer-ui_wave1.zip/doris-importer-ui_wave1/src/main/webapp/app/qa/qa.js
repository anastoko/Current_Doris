'use strict';

angular.module('myApp.qa', ['ngRoute', 'ngResource', 'angular-loading-bar'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/qa', {
            templateUrl: 'qa/qa.html',
            controller: 'QACtrl'
        });
    }])
    .factory('QAImport', ['$resource', function ($resource) {
        return $resource('http://s-cnect-doris-d.cnect.cec.eu.int:8000/doris-importer-api/api/qa', {}, {
            importQA: {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        });
    }])

    .controller('QACtrl', ['$scope'
        , '$rootScope'
        , '$httpParamSerializerJQLike'
        , 'QAImport'
        , function ($scope,
                    $rootScope,
                    $httpParamSerializerJQLike,
                    QAImport) {

            $scope.init = function(){
                $scope.showSuccess = false;
                $scope.showError = false;
            }

            $scope.importQA = function () {
                QAImport.importQA($httpParamSerializerJQLike({
                    alias: $rootScope.alias,
                    filename: $rootScope.filename
                })).$promise.then(function () {
                    $scope.showSuccess = true;
                }).catch(function (response) {
                    $scope.errorMessage = response.data.message;
                    $scope.showError = true;
                });
            };
        }]);