'use strict';

/* https://github.com/angular/protractor/blob/master/docs/toc.md */

describe('my app', function() {


  it('should automatically redirect to /fileupload when location hash/fragment is empty', function() {
    browser.get('index.html');
    expect(browser.getLocationAbsUrl()).toMatch("/fileupload");
  });


  describe('fileupload', function() {

    beforeEach(function() {
      browser.get('index.html#!/fileupload');
    });


    it('should render fileupload when user navigates to /fileupload', function() {
      expect(element.all(by.css('[ng-view] p')).first().getText()).
        toMatch(/partial for view 1/);
    });

  });


  describe('qa', function() {

    beforeEach(function() {
      browser.get('index.html#!/qa');
    });


    it('should render qa when user navigates to /qa', function() {
      expect(element.all(by.css('[ng-view] p')).first().getText()).
        toMatch(/partial for view 2/);
    });

  });
});
